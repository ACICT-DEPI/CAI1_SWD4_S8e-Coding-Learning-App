package com.project.E_learningapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
